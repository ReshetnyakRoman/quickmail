/*
 * This component managing routes
*/

import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import Mailbox from 'containers/Mailbox';
import LoginPage from 'components/LoginPage';

const Routes = props => (
  <div>
    <Route
      path="/welcome"
      render={() => (props.isLoggedIn ? <Redirect to="/" /> : <LoginPage />)}
    />
    <Route
      render={routerProps => {
        if (!props.isLoggedIn) {
          routerProps.history.push('/welcome');
          return <LoginPage />;
        }
        routerProps.history.push('/');
        return <Mailbox />;
      }}
    />
  </div>
);

Routes.propTypes = {
  isLoggedIn: PropTypes.bool,
};

const mapStateToProps = state => ({
  isLoggedIn: state.getIn(['Login', 'isLoggedIn']),
});

export default connect(mapStateToProps)(Routes);
