import { defineMessages } from 'react-intl';

export default defineMessages({
  download: {
    id: 'withRedux.components.Attachments.download',
    defaultMessage: 'Download',
  },
});
