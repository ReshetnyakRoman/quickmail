import { CHANGE_THEME } from './constants';

function changeTheme() {
  return {
    type: CHANGE_THEME,
  };
}

export { changeTheme };
