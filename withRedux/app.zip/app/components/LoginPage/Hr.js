import sytled from 'styled-components';

const Hr = sytled.hr`
  height: 1px;
  background-color: #f0fff0;
  border-width: 0px;
`;

export default Hr;
