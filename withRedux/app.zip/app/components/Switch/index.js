import React from 'react';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import { FormattedMessage } from 'react-intl';
import messages from 'containers/App/messages';
import styled from 'styled-components';
import { withTheme } from '@callstack/react-theme-provider';

const SwitchToogle = props => {
  const {
    checked,
    handleChange,
    msgParametr,
    labelTextID,
    themeDefault,
    theme,
  } = props;

  const variantColors = {
    success: '#4dbd74',
    warning: '#ffc107',
    error: '#f86c6b',
    info: '#20a8d8',
  };

  const StyledSwitch = styled(Switch)`
    & [class*='MuiSwitch-icon'] {
      color: ${checked ? theme.infoColor : theme.successColor};
    }
    & [class*='MuiSwitch-bar'] {
      background-color: ${checked
        ? theme.infoColor
        : theme.successColor} !important;
    }
  `;
  const StyledFormControlLabel = styled(FormControlLabel)`
    & [class*='MuiFormControlLabel'] {
      color: ${theme.sideBarColor} !important;
      font-size: 12px;
    }
  `;
  const StyledFormControl = styled(FormControl)`
    margin: 7px 10px !important;
    padding: 0 !important;
    height: 20px;
  `;

  return (
    <StyledFormControl component="fieldset">
      <StyledFormControlLabel
        control={
          <StyledSwitch
            checked={checked}
            onChange={() => handleChange()}
            value={labelTextID}
          />
        }
        label={
          <FormattedMessage
            {...messages[labelTextID]}
            values={{ msgParametr: msgParametr.toUpperCase() }}
          />
        }
      />
    </StyledFormControl>
  );
};

export default withTheme(SwitchToogle);
