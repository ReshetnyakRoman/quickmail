import { TOOGLE_SIDEBAR_OPEN } from './constants';

function toogleSidebarOpen() {
  return {
    type: TOOGLE_SIDEBAR_OPEN,
  };
}

export { toogleSidebarOpen };
