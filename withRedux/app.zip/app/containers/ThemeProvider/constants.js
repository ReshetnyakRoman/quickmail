const CHANGE_THEME = 'ThemeProvider/CHANGE_THEME';

export { CHANGE_THEME };
